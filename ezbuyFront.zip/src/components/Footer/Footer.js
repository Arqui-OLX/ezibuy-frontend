import React, { Component } from 'react';
//import Col from 'react-bootstrap/Col';
//import Row from 'react-bootstrap/Row';
import './footer-styles.css'


class Footer extends Component{

    
    render(){
        
        return (
            
            <footer>
                
                <p>Términos y condiciones</p>
                <p>EzIBuy.co - 2019</p>
            </footer>        
        );
    }
}

export default Footer;